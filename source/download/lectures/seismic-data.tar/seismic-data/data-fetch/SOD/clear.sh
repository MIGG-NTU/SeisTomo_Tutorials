#!/usr/bin/env bash
#
# Clear SOD database and log files
#

rm -rf SodDb Sod_Error.log Sod.log Fail.log
