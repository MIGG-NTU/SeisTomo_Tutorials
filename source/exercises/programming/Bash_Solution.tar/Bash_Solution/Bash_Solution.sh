#!/bin/sh
awk 'FNR>1{print}' events-selected.dat > events_info.temp
echo "time latitude longitude depth depthUnits magnitude magnitudeType" > events.csv
while read events_info
do
echo $events_info
yyyymmdd=`echo $events_info | awk '{print $1$2$3}'`
hhmmss=`echo $events_info | awk '{print $4":"$5":"$6}'`
latitude=`echo $events_info | awk '{print $8}'`
longitude=`echo $events_info | awk '{print $9}'`
depth=`echo $events_info | awk '{print $10}'`
magnitude=`echo $events_info | awk '{print $11}'`
echo $depth $magnitude
echo "${yyyymmdd}T${hhmmss}Z, ${latitude}, ${longitude}, ${depth}, KILOMETER, ${magnitude}, mww" >> events.csv
done < events_info.temp
rm events_info.temp
