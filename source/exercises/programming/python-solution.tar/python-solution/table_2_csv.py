filename = "events-selected.dat"
csvname = "events-selected.csv"

with open(filename, 'r') as f:
    lines = f.readlines()
f = open(csvname, 'w')
f.write("time, latitude, longitude, depth, depthUnits, magnitude, magnitudeType\n")
for line in lines:
    line = line.strip()
    temp = line.split()
    time = "%s%s%sT%s:%s:%sZ" % tuple(temp[:6])
    lat, lon, dep, mag = temp[7], temp[8], temp[9], temp[10]
    f.write(",".join([time, lat, lon, dep, "KILOMETER", mag, "mww"])+'\n')
f.close()
