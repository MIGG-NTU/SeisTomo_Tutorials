# Program to associate ISC IDs to the events relocated by Antelope
import os
from datetime import *

workdir='./'

## READ ISC ID LIST
isclst='./ISCid.lst'
[iscdate,isctime,isclat,isclon,iscdep,iscid]=[[],[],[],[],[],[]]
iline=0
for line in open(isclst).readlines():
    iline=iline+1
    if iline%4==1:
        iscid.append(line.split()[1])
    elif iline%4==3:
        iscdate.append(line.split()[0])
        isctime.append(line.split()[1])
        isclat.append(float(line.split()[4]))
        isclon.append(float(line.split()[5]))
        iscdep.append(float(line.split()[9].split('f')[0]))

##iscdate=[line.split()[0] for line in open(isclst).readlines()]
##isctime=[line.split()[1] for line in open(isclst).readlines()]
##isclat=[float(line.split()[4]) for line in open(isclst).readlines()]
##isclon=[float(line.split()[5]) for line in open(isclst).readlines()]
##iscdep=[float(line.split()[9].split('f')[0]) for line in open(isclst).readlines()]
##iscid=[line.split()[-1] for line in open(isclst).readlines()]

for subdb in ['1','2','3','4']:
    ## READ LAU ID LIST, this is the new events list determined by Antelope
    laulst=workdir+'ISClauraw'+subdb+'.lst'
    if subdb=='1':
        lauyear=['20'+line.split()[3].split('/')[2] for line in open(laulst).readlines()[1:]]
        laumon=[line.split()[3].split('/')[0] for line in open(laulst).readlines()[1:]]
        lauday=[line.split()[3].split('/')[1] for line in open(laulst).readlines()[1:]]
        lauhour=[line.split()[4].split(':')[0] for line in open(laulst).readlines()[1:]]
        lauminute=[line.split()[4].split(':')[1] for line in open(laulst).readlines()[1:]]
        lausec=[line.split()[4].split(':')[2] for line in open(laulst).readlines()[1:]]
        laulat=[float(line.split()[5]) for line in open(laulst).readlines()[1:]]
        laulon=[float(line.split()[6]) for line in open(laulst).readlines()[1:]]
        laudep=[float(line.split()[7].split('f')[0]) for line in open(laulst).readlines()[1:]]
        lauid=[line.split()[0] for line in open(laulst).readlines()[1:]]
    elif subdb=='2':
        lauyear=[line.split()[1].split('-')[0] for line in open(laulst).readlines()[1:]]
        laumon=[line.split()[1].split('-')[1] for line in open(laulst).readlines()[1:]]
        lauday=[line.split()[1].split('-')[2] for line in open(laulst).readlines()[1:]]
        lauhour=[line.split()[2].split(':')[0] for line in open(laulst).readlines()[1:]]
        lauminute=[line.split()[2].split(':')[1] for line in open(laulst).readlines()[1:]]
        lausec=[line.split()[2].split(':')[2] for line in open(laulst).readlines()[1:]]
        laulat=[float(line.split()[3]) for line in open(laulst).readlines()[1:]]
        laulon=[float(line.split()[4]) for line in open(laulst).readlines()[1:]]
        laudep=[float(line.split()[5].split('f')[0]) for line in open(laulst).readlines()[1:]]
        lauid=[line.split()[0] for line in open(laulst).readlines()[1:]]
    elif subdb=='3':
        lauyear=['20'+line.split()[1].split('/')[2] for line in open(laulst).readlines()[1:]]
        laumon=[line.split()[1].split('/')[0] for line in open(laulst).readlines()[1:]]
        lauday=[line.split()[1].split('/')[1] for line in open(laulst).readlines()[1:]]
        lauhour=[line.split()[2].split(':')[0] for line in open(laulst).readlines()[1:]]
        lauminute=[line.split()[2].split(':')[1] for line in open(laulst).readlines()[1:]]
        lausec=[line.split()[2].split(':')[2] for line in open(laulst).readlines()[1:]]
        laulat=[float(line.split()[3]) for line in open(laulst).readlines()[1:]]
        laulon=[float(line.split()[4]) for line in open(laulst).readlines()[1:]]
        laudep=[float(line.split()[5].split('f')[0]) for line in open(laulst).readlines()[1:]]
        lauid=[line.split()[0] for line in open(laulst).readlines()[1:]]
    elif subdb=='4':
        lauyear=[line.split()[2].split('/')[0] for line in open(laulst).readlines()[1:]]
        laumon=[line.split()[2].split('/')[1] for line in open(laulst).readlines()[1:]]
        lauday=[line.split()[2].split('/')[2] for line in open(laulst).readlines()[1:]]
        lauhour=[line.split()[3].split(':')[0] for line in open(laulst).readlines()[1:]]
        lauminute=[line.split()[3].split(':')[1] for line in open(laulst).readlines()[1:]]
        lausec=[line.split()[3].split(':')[2] for line in open(laulst).readlines()[1:]]
        laulat=[float(line.split()[4]) for line in open(laulst).readlines()[1:]]
        laulon=[float(line.split()[5]) for line in open(laulst).readlines()[1:]]
        laudep=[float(line.split()[6].split('f')[0]) for line in open(laulst).readlines()[1:]]
        lauid=[line.split()[0] for line in open(laulst).readlines()[1:]]        
        
    ## ASSOCIATE ISC ID WITH ANTELOPE ORID
    assfl=open(workdir+subdb+'ass.lst','w') # Output file
    assfl.write('ISC id     Lau ORID\n')
    for lau in range(len(lauid)):
        nass=0
        lauatime=(datetime(int(lauyear[lau]),int(laumon[lau]),int(lauday[lau]),
                           int(lauhour[lau]),int(lauminute[lau]),
                           int(divmod(float(lausec[lau]),1)[0]),
                           int(divmod(float(lausec[lau]),1)[1]*1000000))
                  -datetime(1970,1,1)).total_seconds()
        for isc in range(len(iscid)):
            [year,mon,day]=iscdate[isc].split('/')
            [hour,minute,sec]=isctime[isc].split(':')
            iscatime=(datetime(int(year),int(mon),int(day),int(hour),int(minute),
                            int(divmod(float(sec),1)[0]),
                            int(divmod(float(sec),1)[1]*1000000))
                            -datetime(1970,1,1)).total_seconds()
####        Compare time, lat, lon, and dep list in the ISC catalog and our new results
####        If they are nearly the same, then we can associate the two events
            if (abs(iscatime-lauatime)<60 and abs(laulat[lau]-isclat[isc])<0.1
                and abs(laulon[lau]-isclon[isc])<0.1 and
                abs(laudep[lau]-iscdep[isc])<10):
                assfl.write('%s    %s\n' % (iscid[isc],lauid[lau]))
                nass=nass+1
        if nass>1:
            exit('%s has multipule associations' % iscid[isc])
        elif nass==0:
            for isc in range(len(iscid)):
                [year,mon,day]=iscdate[isc].split('/')
                [hour,minute,sec]=isctime[isc].split(':')
                iscatime=(datetime(int(year),int(mon),int(day),int(hour),int(minute),
                                int(divmod(float(sec),1)[0]),
                                int(divmod(float(sec),1)[1]*1000000))
                                -datetime(1970,1,1)).total_seconds()
                if (abs(iscatime-lauatime)<120 and abs(laulat[lau]-isclat[isc])<0.5
                    and abs(laulon[lau]-isclon[isc])<0.5 and
                    abs(laudep[lau]-iscdep[isc])<100):
                    assfl.write('%s    %s  %7.2f  %7.2f  %7.2f  %7.2f\n' %
                                (iscid[isc],lauid[lau],abs(iscatime-lauatime),
                                 abs(laulat[lau]-isclat[isc]),
                                 abs(laulon[lau]-isclon[isc]),
                                 abs(laudep[lau]-iscdep[isc])))
                    nass=nass+1
        if nass>1:
            exit('%s has multipule associations' % iscid[isc])
        elif nass==0:
            assfl.write('-1111111    %s\n' % (lauid[lau]))
    assfl.close()
        
