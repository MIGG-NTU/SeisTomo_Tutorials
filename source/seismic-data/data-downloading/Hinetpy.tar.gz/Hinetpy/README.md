# An example of HinetPy

The script is used to download waveforms from [Hi-net](https://www.hinet.bosai.go.jp/?LANG=en) using the python package [HinetPy](https://github.com/seisman/HinetPy).

You need to first apply for a Hinet [account](https://hinetwww11.bosai.go.jp/auth/?LANG=en). Then, you can apply for the continuous waveform around the origin time of events in `CMTlist` using python script `Continue_Waveform_Hinet.py`.

```python
python Continuous_Waveform_Hinet.py ./CMTlist ./Waveform 0101,0103
```

CMTlist can be accessed in [GCMT](https://www.globalcmt.org/).
